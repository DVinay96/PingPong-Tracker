import { render, screen, fireEvent } from "@testing-library/react";
//  for additional matchers
import Form from "./components/Form"; // Adjust the path as necessary
import React from "react";

describe("Input Component", () => {
  it("should display the correct initial value and update when typed into", () => {
    // Render the Input component
    render(<Form placeholder="Type here..." />);

    // Get the input element by its test ID
    const inputElement = screen.getByTestId("input");

    // Assert that the initial value is empty
    expect(inputElement.value).toBe("");

    // Simulate typing into the input
    fireEvent.change(inputElement, { target: { value: "Hello, world!" } });

    // Assert that the input value is updated correctly
    expect(inputElement.value).toBe("Hello, world!");
  });
});
